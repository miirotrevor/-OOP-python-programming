name = input("What is your lovely name? ")
print("Hello,", name)
