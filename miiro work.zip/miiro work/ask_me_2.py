try:
    name = input("What is your lovely name? ")
    print("Hello, " , name)
except ValueError:
    print("Hello, stranger.")

